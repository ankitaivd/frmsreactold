import React, {useState} from 'react'; 
import Modal from 'react-modal'


const Error = () => {
   
return (
    <>
    <div className="margin-top">
    <h1>OOps! Page not found</h1>  
    </div>

    
   
  </>  
);
}
export default Error
    