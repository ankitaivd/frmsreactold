import React,{useState,useEffect} from "react";
import { withStyles } from '@material-ui/styles';
import MuiAccordion from '@material-ui/core/Accordion';
import MuiAccordionSummary from '@material-ui/core/AccordionSummary';
import MuiAccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import Modal from 'react-bootstrap/Modal';
import { siteData } from "./../../actions/siteData";
import axios from 'axios';
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect,
  Switch,
  useHistory ,
  useLocation,
  withRouter,
  useParams
  }from 'react-router-dom'

const Applicationstatus = () => {

  const Axios = axios.create({
    baseURL: process.env.REACT_APP_ENV_URL   
  });

  const [allBookings, setAllBookings] = useState([]);
 const [paginationfac,setPaginationfac] = useState({perPage:10,totalCount:0,totalPage:1,currentPage:1})
   const [addindexfac, setAddindexfac] = useState();
const callPaginationfac =(s)=>{
console.log(s);
console.log(paginationfac.currentPage);
console.log(paginationfac.totalPage);
let a=paginationfac.currentPage;
if(s==='nextPage' && paginationfac.currentPage < paginationfac.totalPage){
  a = a+1;
}

if(s==='previouPage' && paginationfac.currentPage > 1 && paginationfac.currentPage <= paginationfac.totalPage){
  a = a-1;
}


if(paginationfac.currentPage === a){

  return false;
}


 Axios.post("getMyProfileAdmin",{id:0,status:'locassign',perpage:paginationfac.perPage,page:a})
.then(res =>{

  
      console.log(res.data);
       setAllBookings(res.data.totaldetailsbooknew);
       setPaginationfac((preValue)=>{
      return { 
         perPage:preValue.perPage,
      totalCount:res.data.pagination.totalCount,
      totalPage:res.data.pagination.totalPage,
      currentPage:a   
      }   
    });
       var pagefa=((parseInt(a) * parseInt(paginationfac.perPage))-parseInt(paginationfac.perPage));
       
       
        if(pagefa >= 10){
          setAddindexfac(parseInt(pagefa));
          console.log(parseInt(pagefa));
        }else{
          setAddindexfac(1);
        }
     


})
.catch(error=>{
  console.log("not found");
});




}
  useEffect(() => {
  Axios.post("getMyProfileAdmin",{id:0,status:'locassign',perpage:10,page:1})
.then(res =>{
  console.log("Get Data");
  console.log(res.data);
  setAllBookings(res.data.totaldetailsbooknew);
     setPaginationfac((preValue)=>{
      return { 
        perPage:10,
        totalCount:res.data.pagination.totalCount,
        totalPage:res.data.pagination.totalPage,
        currentPage:1  
      }   
    });
});


},[]);
  
return (
   <>
   <div class="content content-fixed">
     
     <div class="container-admin pd-x-0 pd-lg-x-10 pd-xl-x-0">
  
       <div data-label="Example" class="df-example demo-table">
           <div class="table-responsive dataTables_wrapper no-footer">
{/*             <div class="dataTables_length length-data" style={{marginTop:'7px', marginBottom: '0px', fontFamily: 'IBM Plex Sans'}} id="example1_length"><label><select name="example1_length" aria-controls="example1" class=""><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select></label></div>*/}
             <div id="example1_filter" class="dataTables_filter search-data search-bottom"><label>
               <input type="search" class="search-data" placeholder="Search..." aria-controls="example1" style={{fontFamily: 'IBM Plex Sans'}}/></label></div>
               
             <table class="table table-bordered mg-b-0 text-center">
               <thead>
                 <tr class="heading-sec-table">
                   <th scope="col" style={{width:'110px'}}>Sl No</th>
                   <th scope="col">Location</th>
                   <th scope="col" style={{width:'400px'}}>Facilities</th>
                   <th scope="col">Requested Date</th>
                   <th scope="col">Requested hour</th>
                   <th scope="col">Status</th>
                   <th scope="col">Action</th>
                 </tr>
               </thead>
               <tbody class="tbody-color tbody-view">

               { allBookings.length > 0 ? <>
           {   allBookings.map((post,index)=>( 
                 <tr>
                   <th scope="row">{index+1}</th>
                   <td>{post.details.locationName}</td>
                   <td>{post.details.facilityName}</td>
                   <td>{post.details.bookingDate}</td>
                 
                   <td>{post.timediffen}</td>
                   <td>
                     {post.details.status==='locassign'?'Booking Pending':''}
                     {post.details.status==='approved'?'Booking Approved':''}
                     {post.details.status==='rejected'?'Booking not approved':''}
                     </td>
                   <td>
                     <Link to={`/Createestimate/${post.details.bid}`} class="crete-sec" style={{color:'#0AB50A'}}>{post.details.status==='approved'?'Create Estimate':''}</Link></td>
                 </tr>
           ))}</>:<></>}
               
               
               </tbody>
             </table>
             <div className="dataTables_info" id="example2_info" role="status" aria-live="polite" style={{color:'#707070', fontSize: '15px'}}>Showing {(paginationfac.currentPage * paginationfac.perPage)-paginationfac.perPage } to {(paginationfac.currentPage * paginationfac.perPage)>paginationfac.totalCount?paginationfac.totalCount:paginationfac.currentPage * paginationfac.perPage} of {paginationfac.totalCount} entries</div>
              <div style={{width: 'auto', float: 'right', border: '1px solid #ccc', marginTop:'20px'}}>
                <div style={{float: 'left', padding: '5px 10px', background: '#f79e00', color: '#fff', fontSize: '14px'}}> Page {paginationfac.currentPage}<span> of </span> {paginationfac.totalPage} </div>
<div  onClick={()=>callPaginationfac('previouPage')}  style={{float: 'left', cursor: 'pointer', fontSize: '18px', lineHeight: '18px', marginTop: '6px', marginLeft: '10px', color: '#f79e00'}}>&lt;</div>
                <span style={{float: 'left', fontSize: '14px', marginTop: '6px', marginLeft: '10px', color:'#707070;'}}>Go To</span>
                <input  value={paginationfac.currentPage}  type="text" style={{color:'#707070',fontSize: '14px', width: '31px', float: 'left', height: '22px', marginBottom: '0', textAlign: 'center', marginLeft: '4px', marginTop: '4px', border: '1px solid #f79e00'}} />
 <div onClick={()=>callPaginationfac('nextPage')} style={{float: 'left', cursor: 'pointer', fontSize: '18px', lineHeight: '18px', marginTop: '8px', marginLeft: '10px', marginRight: '8px', color: '#f79e00'}}>&gt;</div>
              </div>

           </div>
         </div>

</div>
</div>
   </>
)
}
export default Applicationstatus